#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "ustarheader.h"

#define TAILLE 1000

int main(int argc, char** argv) {
	FILE* fichier = fopen("archive.tar", "r");
	char l[TAILLE] = "";
	FILE_HEADER fh;

	if(fichier != NULL) {
		fseek(fichier, 0, SEEK_END);
		printf("Taille de l'archive: %ld\n", ftell(fichier));
		rewind(fichier);

		fread(fh.name, NAME_S, 1, fichier);
		fread(fh.mode, MODE_S, 1, fichier);
		fread(fh.uid, UID_S, 1, fichier);
		fread(fh.gid, GID_S, 1, fichier);
		fread(fh.size, SIZE_S, 1, fichier);
		fread(fh.mtime, MTIME_S, 1, fichier);
		fread(fh.cksum, CKSUM_S, 1, fichier);
		fread(fh.typeflag, TYPEFLAG_S, 1, fichier);
		fread(fh.linkname, LINKNAME_S, 1, fichier);
		fread(fh.magic, MAGIC_S, 1, fichier);
		fread(fh.version, VERSION_S, 1, fichier);
		fread(fh.uname, UNAME_S, 1, fichier);
		fread(fh.gname, GNAME_S, 1, fichier);
		fread(fh.devmajor, DEVMAJOR_S, 1, fichier);
		fread(fh.devminor, DEVMINOR_S, 1, fichier);
		fread(fh.prefix, PREFIX_S, 1, fichier);

		printf_header(fh);

		fclose(fichier);
	}

	return EXIT_SUCCESS;
}